from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from urllib.parse import quote_plus, urlencode
from authlib.integrations.flask_client import OAuth
import secrets

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = "YOUR_SECRET_KEY"  # Set a secret key for session management

db = SQLAlchemy(app)

# Auth0 details
AUTH0_CLIENT_ID = 'YvFGvcbrZ9jTTHHVxcXQtvB1HigZEYVV'
AUTH0_CLIENT_SECRET = 'nk8wPiXLFYs9WeY22s-_spWQz16hluls_qRDLGLJrqZ9mDrhP_Yxr8mMC-GBShZ6'
AUTH0_DOMAIN = 'dev-njie83mu3ou46xvv.us.auth0.com'

# Set up Auth0 integration
oauth = OAuth(app)
auth0 = oauth.register(
    "auth0",
    client_id=AUTH0_CLIENT_ID,
    client_secret=AUTH0_CLIENT_SECRET,
    client_kwargs={
        "scope": "openid profile email",
    },
    server_metadata_url=f'https://{AUTH0_DOMAIN}/.well-known/openid-configuration'
)

# Home route
@app.route("/")
def home():
    return render_template('home.html')  # Create a home.html page

# Login route
@app.route("/login")
def login():
    nonce = secrets.token_urlsafe(16)
    session['nonce'] = nonce
    return auth0.authorize_redirect(
        redirect_uri=url_for("callback", _external=True), nonce=nonce
    )

# Signup route
@app.route("/signup")
def signup():
    nonce = secrets.token_urlsafe(16)
    session['nonce'] = nonce
    return auth0.authorize_redirect(
        redirect_uri=url_for("callback", _external=True),
        screen_hint="signup", nonce=nonce  # This tells Auth0 to show the signup page
    )

# Callback route (after Auth0 login/signup)
@app.route("/callback", methods=["GET", "POST"])
def callback():
    token = auth0.authorize_access_token()

    # Parse and validate the ID token (this is where nonce validation occurs)
    nonce = session.get('nonce')  # Retrieve the nonce from the session
    userinfo = oauth.auth0.parse_id_token(token, nonce=nonce)

    # Store user information in session
    session["user"] = {
        "user_id": userinfo["sub"],
        "name": userinfo["name"],
        "email": userinfo["email"],
        "picture": userinfo["picture"],
    }

    return redirect("/dashboard")  # Redirect to a dashboard page after login/signup

# Dashboard route (protected)
@app.route("/dashboard")
def dashboard():
    user = session.get("user")
    if not user:
        return redirect(url_for("login"))

    return render_template("dashboard.html", user=user)  # Create a dashboard.html page

# Logout route
@app.route("/logout")
def logout():
    session.clear()
    return redirect(
        "https://" + AUTH0_DOMAIN
        + "/v2/logout?"
        + urlencode(
            {
                "returnTo": url_for("home", _external=True),
                "client_id": AUTH0_CLIENT_ID,
            },
            quote_via=quote_plus,
        )
    )

if __name__ == "__main__":
    app.run(debug=True)
