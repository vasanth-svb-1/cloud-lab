from flask import Flask, render_template, request, redirect, url_for,jsonify,session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Firebase - Authentication
import firebase_admin
from firebase_admin import credentials,firestore,auth
cred = credentials.Certificate("lec-lib-firebase-adminsdk-gl2j8-c9327f7ad4.json") #Generate from service accounts
#Firebase db
from firebase_admin import db as firebase_db
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://lec-lib-default-rtdb.firebaseio.com/'  # Replace with your Firebase Realtime Database URL
})
db_firestore = firestore.client()
app.secret_key = 'AIzaSyDmSVaiN-q_Bkv67hbsiZmgpdtS0YNOe4I'

#Auth0
from os import environ as env
from urllib.parse import quote_plus, urlencode

from authlib.integrations.flask_client import OAuth
from dotenv import find_dotenv, load_dotenv

ENV_FILE = find_dotenv()
if ENV_FILE:
    load_dotenv(ENV_FILE)

oauth = OAuth(app)
oauth.register(
    "auth0",
    client_id=env.get("AUTH0_CLIENT_ID"),
    client_secret=env.get("AUTH0_CLIENT_SECRET"),
    client_kwargs={
        "scope": "openid profile email",
    },
    server_metadata_url=f'https://{env.get("AUTH0_DOMAIN")}/.well-known/openid-configuration'
)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        try:
            # Create a new user with Firebase Authentication
            user = auth.create_user(
                email=email,
                password=password
            )
            return jsonify({'message': 'User created successfully!'}), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    return render_template('signup.html')

@app.route("/login_auth0")
def login_auth0():
    return oauth.auth0.authorize_redirect(
        redirect_uri=url_for("callback", _external=True)
    )

# 👆 We're continuing from the steps above. Append this to your server.py file.

@app.route("/callback", methods=["GET", "POST"])
def callback():
    token = oauth.auth0.authorize_access_token()
    session["user_id"] = token
    return redirect("/")

# 👆 We're continuing from the steps above. Append this to your server.py file.

@app.route("/logout_auth0")
def logout_auth0():
    session.clear()
    return redirect(
        "https://" + env.get("AUTH0_DOMAIN")
        + "/v2/logout?"
        + urlencode(
            {
                "returnTo": url_for("home", _external=True),
                "client_id": env.get("AUTH0_CLIENT_ID"),
            },
            quote_via=quote_plus,
        )
    )
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        try:
            # Firebase Authentication (sign in with email and password)
            user = auth.get_user_by_email(email)
            session['user_id'] = user.uid  # Save user ID in session

            return redirect(url_for('index'))  # Redirect to user dashboard
        except Exception as e:
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)  # Remove user ID from session
    return redirect(url_for('index'))

# Book model
class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    genre = db.Column(db.String(50), nullable=False)

# Home page: show all books
def create_tables():
    with app.app_context():
        db.create_all()
create_tables()
@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    books = Book.query.all()
    return render_template('index.html', books=books)
@app.route('/books-rtdb', methods=['GET'])
def get_books():
    # Get a reference to the 'books' node
    ref = firebase_db.reference('books')

    # Get all books from the 'books' node
    books = ref.get()

    return jsonify(books)

# Add a new book
@app.route('/add', methods=['GET', 'POST'])
def add_book():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        genre = request.form['genre']
        new_book = Book(title=title, author=author, genre=genre)

        db.session.add(new_book)
        db.session.commit()

        #Firebase real time database
        ref = firebase_db.reference('books')

    # Push a new book under the 'books' node
        new_book_ref = ref.push({
        'title': title,
        'author': author,
        'genre': genre
        })
        return redirect(url_for('index'))

    return render_template('add_book.html')

# Edit a book
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_book(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    book = Book.query.get_or_404(id)

    if request.method == 'POST':
        book.title = request.form['title']
        book.author = request.form['author']
        book.genre = request.form['genre']

        db.session.commit()
        return redirect(url_for('index'))

    return render_template('edit_book.html', book=book)

# Delete a book
@app.route('/delete/<int:id>')
def delete_book(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    book = Book.query.get_or_404(id)
    db.session.delete(book)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
