from flask import Flask, render_template, request, redirect, url_for, g
from flask_pymongo import PyMongo
from bson.objectid import ObjectId
import os

app = Flask(__name__)

# MongoDB Atlas connection
app.config["MONGO_URI"] = "mongodb+srv://vasanthbupathi:SVB%40917722IT125@lec-lib.urtyl.mongodb.net/lec-lib?retryWrites=true&w=majority&appName=lec-lib"
mongo = PyMongo(app)

def get_db():
    if 'db' not in g:
        g.db = mongo.db
    return g.db
    
# Home route
@app.route('/')
def index():
    return render_template('base.html')

# View All Books (READ)
@app.route('/books', methods=['GET'])
def get_books():
    db = get_db()
    book_collection = db.books
    books = book_collection.find()
    book_list = [{"id": str(book["_id"]), "title": book["title"], "author": book["author"]} for book in books]
    return render_template('books.html', books=book_list)

# Add Book Page
@app.route('/add_book_page', methods=['GET'])
def add_book_page():
    return render_template('add_book.html')

# Add Book (CREATE)
@app.route('/add_book', methods=['POST'])
def add_book():
    title = request.form.get('title')
    author = request.form.get('author')

    db = get_db()
    book_collection = mongo.db.books
    book_collection.insert_one({"title": title, "author": author})

    return redirect(url_for('get_books'))

# Update Book Page (Form)
@app.route('/update_book_page/<id>', methods=['GET'])
def update_book_page(id):
    db = get_db()
    book_collection = db.books
    book = book_collection.find_one({"_id": ObjectId(id)})

    if book:
        book_data = {"id": str(book["_id"]), "title": book["title"], "author": book["author"]}
        return render_template('update_book.html', book=book_data)
    else:
        return "Book not found", 404

# Update Book (UPDATE)
@app.route('/update_book/<id>', methods=['POST'])
def update_book(id):
    title = request.form.get('title')
    author = request.form.get('author')

    db = get_db()
    book_collection = db.books
    book_collection.update_one({"_id": ObjectId(id)}, {"$set": {"title": title, "author": author}})

    return redirect(url_for('get_books'))

# Delete Book (DELETE)
@app.route('/delete_book/<id>', methods=['GET'])
def delete_book(id):
    db = get_db()
    book_collection = db.books
    book_collection.delete_one({"_id": ObjectId(id)})

    return redirect(url_for('get_books'))

if __name__ == '__main__':
    app.run(debug=True)
